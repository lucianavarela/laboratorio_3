<?php

$nombre = $_REQUEST['nombre'];

$clave = $_REQUEST['clave'];

echo $nombre . ' ' . $clave;


?>