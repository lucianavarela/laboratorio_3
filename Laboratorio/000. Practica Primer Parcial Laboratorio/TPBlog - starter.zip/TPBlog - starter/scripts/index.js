var xhr;
var datos = new Array();

function cargarDatos(){

    
}

window.onload = function(){
    cargarDatos();
    
}


