"use strict";
var Clases;
(function (Clases) {
    var tipoHeroe;
    (function (tipoHeroe) {
        tipoHeroe[tipoHeroe["Xmen"] = 0] = "Xmen";
        tipoHeroe[tipoHeroe["Avenger"] = 1] = "Avenger";
    })(tipoHeroe = Clases.tipoHeroe || (Clases.tipoHeroe = {}));
})(Clases || (Clases = {}));
//# sourceMappingURL=enumerados.js.map