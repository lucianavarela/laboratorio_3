namespace Clases{

   export enum tipoHeroe{
        Xmen,
        Avenger
    }

}